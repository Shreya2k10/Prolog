powerset([], []).
powerset([E|Tail], [E|OtherTail]) :-
    powerset(Tail, OtherTail).
powerset([_|Tail], OtherTail) :-
    powerset(Tail, OtherTail).
