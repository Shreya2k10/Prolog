sumList([],0).
ssumList([H|T],N):-sumList(T,N1), N is N1+H.