fact(0,1).
fact(N,Fn):-
	N1 is N-1,
	fact(N1,Fn1),
	Fn is N*Fn1.

