
% union(+List1, +List2, -Result)
% This predicate takes two lists as input and returns a new list containing all the elements from both input lists without duplicates.
% L2: The first input list.
% L3: The second input list.
% T: The resulting list containing all the elements from List1 and List2 without duplicates.

union([], L, L).
union([H|T], L2, L3) :-
    select(H, L2, L2_),
    union(T, L2_, L3).
union([H|T], L2, [H|L3]) :-
    \+ member(H, L2),
    union(T, L2, L3).
    
 /** Input format    union([4, 9, 5], [9, 4, 9, 8,4], Result). */