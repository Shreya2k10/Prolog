% powerset(+List, -Result)
% This predicate takes a list as input and returns a new list containing all possible subsets of the input list.
% List: The input list.
% Result: The resulting list containing all possible subsets of List.
powerset([], [[]]). % The power set of an empty list is a list containing an empty list
powerset([H|T], P) :- % The power set of a non-empty list is obtained by
    powerset(T, PT), % Finding the power set of the tail of the list
    maplist(add_head(H), PT, PTH), % Adding the head of the list to each subset in the power set of the tail
    append(PT, PTH, P). % Appending the two lists of subsets to get the final power set

% A helper predicate to add an element to the head of a list
add_head(H, T, [H|T]).

% A predicate to reverse a list
reverse([], []). % The reverse of an empty list is an empty list
reverse([H|T], R) :- % The reverse of a non-empty list is obtained by
    reverse(T, RT), % Reversing the tail of the list
    append(RT, [H], R). % Appending the head of the list to the end of the reversed tail

% A predicate to write only R and not P without duplicates 
write_only_r(L) :-
    powerset(L, P), % Find the power set of L and store it in P
    reverse(P, R), % Reverse P and store it in R
    sort(R, Sorted_R),
    write_list_to_file('output.txt', Sorted_R). % Write R without duplicates to file

% A helper predicate to write a list to a file
loop_through_list(File, []) :- !.
loop_through_list(File, [Head|Tail]) :-
    write(File, Head),
    write(File, ' '),
    loop_through_list(File, Tail).

% This writes output to file named output.txt located in same directory
write_list_to_file(Filename,List) :-
    open(Filename, write, File),
    loop_through_list(File, List),
    close(File).

% Input format: write_only_r([11, 2, 3]).

