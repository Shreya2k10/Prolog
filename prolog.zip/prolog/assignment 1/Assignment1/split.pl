split_list(L, X) :-
    length(L, K), /**Here length is being computed by built in function length and stored in K */
    split_list_helper(L, K, X, []).

split_list_helper([], 1, _, Acc) :- sum_list(Acc, Sum), Sum >= 0, !.
split_list_helper(L, K, X, Acc) :- /**Here acc is am accumlater updated in each rucursive call*/
    append(H, Rest, L),
    H \= [], /** Means H\= []*/
    (   length(H, 1)
    ;   sum_list(H, Sum), Sum >= X
    ),
    K1 is K - 1,
    split_list_helper(Rest, K1, X, H).


/** Input format- split_list([2, 2, 1], 4). */


/** Input format- split_list([2, 1, 3], 5). */