% intersection(+List1, +List2, -Result)
% This predicate takes two lists as input and returns a new list containing the common elements between the two input lists.
% L1: The first input list.
% L2: The second input list.
% Res: The resulting list containing the common elements between List1 and List2.
intersection([], _, []).
intersection([H|T], L2, [H|Res]) :-
    member(H, L2), !,
    select(H, L2, L2_),
    intersection(T, L2_, Res).
intersection([_|T], L2, Res) :-
    intersection(T, L2, Res).

/** intersection([4, 9, 5], [9, 4, 9, 8, 4], Result). */
    