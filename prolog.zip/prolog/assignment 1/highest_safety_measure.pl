% This is a code block
% A predicate to check if a list can be split into valid sublists
split(L, X) :-
    split(L, X, []). % Call the helper predicate with an empty accumulator

% A helper predicate that takes three arguments: L is the list to be split, X is the value to compare with, and A is the accumulator that stores the sublists
split([], _, A) :- % Base case: if the list is empty
    forall(member(S, A), (length(S, 1) ; sumlist(S, Y), Y >= X)). % Check if every sublist in the accumulator satisfies the condition
split([H|T], X, A) :- % Recursive case: if the list is not empty
    (A = [] -> % If the accumulator is empty
        split(T, X, [[H]]) % Start a new sublist with the first element of the list
    ; % Else
        last(A, S), % Get the last sublist in the accumulator
        (length(S, 1) ; sumlist(S, Y), Y >= X) -> % If the last sublist satisfies the condition
            split(T, X, [[H]|A]) % Start a new sublist with the next element of the list
        ; % Else
            append(S, [H], S1), % Append the next element to the last sublist
            append(A1, [_], A), % Remove the last sublist from the accumulator
            split(T, X, [S1|A1]) % Continue with the updated sublist and accumulator
    ).